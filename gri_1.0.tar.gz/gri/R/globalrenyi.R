#' Global Renyi index
#'
#' @param d Distance matrix
#' @param p The interval of the threshold ratio.
#' @param p0 A parameter used to select the threshold ratio.
#' @param q Parameter of the dimension.
#'
#' @return A list that includes GRI and thresholds.
#' @export
#'
#' @examples
#' d=as.matrix(dist(matrix(runif(1000,0,1),500,2)))
#' grivalue=globalrenyi(d,c(0.05,0.1),0.001,2)
#' grivalue$GRI
#' thRq=grivalue$thRq
#' plot(thRq[,1],thRq[,2])
globalrenyi<-function(d,p,p0,q){
  netseq=networkseq(d,p,p0)
  adj=netseq$adj
  th=netseq$th
  n=dim(adj)
  n3=n[3]
  n2=n[2]
  Rq=matrix(0,n3,1)
  md=matrix(0,n3,1)
  for(i in 1:n3){
    md[i]=sum(adj[,,i])/n2
  }
  for(i in 1:n3){
    Rq[i]=1-sum((rowSums(adj[,,i],dims=1)/md[i])^q*(1/n[2]))^(1/(1-q))
  }
  GRI1=mean(Rq)

  thRq=cbind(th,Rq)
  m=lm(Rq~th+I(th^2)+I(th^3))
  coe=m$coefficients
  f<-function(x)coe[1]+coe[2]*x+coe[3]*x^2+coe[4]*x^3
  GRI2=(integrate(f,th[1],th[n3])$value)/(th[n3]-th[1])
  GRI=c(GRI1,GRI2)
  output=list(GRI=GRI,thRq=thRq,coe=coe)
  return(output)
}
