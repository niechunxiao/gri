#' Generalized correlation dimension
#'
#' @param d Distance matrix
#' @param p The interval of the threshold ratio.
#' @param p0 A parameter used to select the threshold ratio.
#' @param q Parameter of the dimension.
#'
#' @return A list that includes dimension and thresholds.
#' @export
#'
#' @examples
#' d=as.matrix(dist(matrix(runif(1000,0,1),500,2)))
#' cordim=correlationdimq(d,c(0.01,0.05),0.001,2)
#' cordim$coer2
#' thC2=cordim$thCq
#' plot(thC2[,1],thC2[,2])
correlationdimq<-function(d,p,p0,q) {
  netseq=networkseq(d,p,p0)
  adj=netseq$adj
  th=netseq$th
  n=dim(adj)
  n3=n[3]
  Cq=matrix(0,n3,1)
  for(i in 1:n3){
    Cq[i]=((sum(rowSums(adj[,,i],dims=1)^(q-1)))/n[2])^(1/(q-1))
  }
  lth = log(th)
  lCq = log(Cq)
  m = lm(lCq ~ lth)
  coe = as.matrix(m$coefficients)
  thCq = cbind(lth, lCq)
  r2=summary(m)$r.squared
  output = list(coer2 = c(coe,r2),thCq = thCq, th = th)
  return(output)
}
