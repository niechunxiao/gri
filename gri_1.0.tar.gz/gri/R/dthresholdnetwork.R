#' Threshold network
#'
#' @param d Distance matrix
#' @param th0 Threshold
#'
#' @return Adjacency matrix
#' @export
#'
#' @examples
#' d=as.matrix(dist(matrix(runif(1000,0,1),500,2)))
#' adj=dthresholdnetwork(d,0.01)
dthresholdnetwork<-function(d,th0){
  adj=ifelse(d<th0,1,0)
  diag(adj)=0
  return(adj)
}
