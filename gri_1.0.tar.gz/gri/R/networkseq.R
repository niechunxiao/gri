#' Threshold network sequence
#'
#' @param d Distance matrix
#' @param p The interval of the threshold ratio.
#' @param p0 A parameter used to select the threshold ratio.
#'
#' @return The network sequence of matrix d.
#' @export
#'
#' @examples
#' d=as.matrix(dist(matrix(runif(1000,0,1),500,2)))
#' netseq=networkseq(d,c(0.05,0.1),0.001)
networkseq<-function(d,p,p0){
  nd = dim(d)
  ds1 = sort(unique(c(d)))
  ds = ds1[-1]
  n = length(ds)
  L = floor(n * seq(from = p[1], to = p[2], by = p0))
  th = ds[L]
  n1 = length(th)
  adj = array(data = 0, dim = c(nd[1], nd[2], n1))
  md = matrix(data = 0, nrow = n1, ncol = 1)
  for (i in 1:n1) {
    adj[, , i] = dthresholdnetwork(d, th[i])
  }
  output=list(adj=adj,th=th)
  return(output)
}
